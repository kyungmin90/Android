package util;

import java.util.ArrayList;

public class SetValue {
	public static String setValue(String name, String value) {
		if (value == null) {
			return null;
		} else {
			return name + "=" + value;
		}
	}

	public static ArrayList<String> setValues(ArrayList<String> list) {
		ArrayList<String> filter = new ArrayList<String>();
		
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) != null) {
				filter.add(list.get(i));
			}
		}
		
		return filter;
	}

//	public static String setValue(String name, String value) {
//		if (value == null) {
//			return name + "=1 OR " + name + " IS " + value;
//		} else {
//			return name + "=" + value;
//		}
//	}
}
