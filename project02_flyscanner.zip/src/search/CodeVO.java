package search;

public class CodeVO {
	int cdID;
	String category;
	String opt;

	public int getCdID() {
		return cdID;
	}

	public void setCdID(int cdID) {
		this.cdID = cdID;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getOpt() {
		return opt;
	}

	public void setOpt(String opt) {
		this.opt = opt;
	}

}
