package recommend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class HashtagDAO {
	String url = "jdbc:mysql://localhost:3366/flyscanner";
	String user = "root";
	String password = "1234";
	Connection con;

	public HashtagDAO() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(url, user, password);
		System.out.println("DB연결 성공!");
	}

	public ArrayList<HashtagDTO> read(ArrayList<String> list, String[] continent) throws Exception {
		ArrayList<HashtagDTO> data = new ArrayList<HashtagDTO>();
		String contin = null;
		if (continent != null) {
			contin = "(continent IN (";
			for (int i = 0; i < continent.length; i++) {
				contin = contin + continent[i] + ",";
			}
			contin = contin.substring(0, contin.length() - 1) + "))";
		}
		System.out.println("나는대륙: " + contin);

		String sql = "SELECT nation FROM hashtag INNER JOIN country ON hashtag.ctID=country.ctID WHERE " + contin + " AND ";

		for (int i = 0; i < list.size(); i++) {
			sql = sql + list.get(i) + "=1 AND ";
		}
		sql = sql.substring(0, sql.length() - 5);
		System.out.println(sql);

		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();


		while (rs.next()) {
			HashtagDTO dto = new HashtagDTO();
			String nation = rs.getString("nation");
			dto.setCtID(nation);
			
			data.add(dto);
		}
		
		return data;
	}
	
	public ArrayList<HashtagDTO> read2(ArrayList<String> list, String[] continent) throws Exception {
		ArrayList<HashtagDTO> data = new ArrayList<HashtagDTO>();
		String contin = null;
		if (continent != null) {
			contin = "(continent IN (";
			for (int i = 0; i < continent.length; i++) {
				contin = contin + continent[i] + ",";
			}
			contin = contin.substring(0, contin.length() - 1) + "))";
		}
		System.out.println("나는대륙: " + contin);
		
		// 일단 가격은 제외..
		// and (food is null or food = 1);
//		String sql = "SELECT ctID FROM hashtag WHERE " + contin + " AND ";
		String sql = "SELECT nation FROM hashtag INNER JOIN country ON hashtag.ctID=country.ctID WHERE " + contin + " AND (";
		
		for (int i = 0; i < list.size(); i++) {
			sql = sql + list.get(i) + "=1 OR ";
		}
		sql = sql.substring(0, sql.length() - 4) + ")";
		System.out.println(sql);
		
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		
		
		while (rs.next()) {
			HashtagDTO dto = new HashtagDTO();
			String nation = rs.getString("nation");
			dto.setCtID(nation);
			
			data.add(dto);
		}
		
		return data;
	}
	
	public ArrayList<String> read3(String[] continent, String[] theme) throws Exception {
		ArrayList<HashtagDTO> data = new ArrayList<HashtagDTO>();
		ArrayList<String> list = new ArrayList<String>();
		
		String contin = null;
		if (continent != null) {
			contin = "(continent IN (";
			for (int i = 0; i < continent.length; i++) {
				contin = contin + continent[i] + ",";
			}
			contin = contin.substring(0, contin.length() - 1) + "))";
		}
		System.out.println("나는대륙: " + contin);
		
		String sql = "SELECT nation FROM hashtag INNER JOIN country ON hashtag.ctID=country.ctID WHERE " + contin + " AND (";
		if (theme.length > 0) {
			for (int i = 0; i < theme.length; i++) {
				sql = sql + theme[i] + "=1 OR ";
			}
			sql = sql.substring(0, sql.length() - 4) + ")";
			System.out.println(sql);			
		}
		
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) {
			HashtagDTO dto = new HashtagDTO();
			String nation = rs.getString("nation");
//			dto.setCtID(nation);
			list.add(nation);
//			data.add(dto);
		}

		for (int i = 0; i < data.size(); i++) {
			System.out.println("나:   "+data.get(i));
		}
		
		return list;
	}
}
